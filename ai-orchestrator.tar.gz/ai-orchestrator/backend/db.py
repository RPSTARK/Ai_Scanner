"""
SQLite persistence layer.

Tables:
  - adapter_configs: per-adapter config values (API keys, scan scope, etc.)
  - targets: saved scan targets (so you don't retype endpoints/auth)
  - scans: scan history (target snapshot + consolidated result JSON)

A single local file (orchestrator.db) - no external DB needed, part of the
"single command install" promise.
"""

import os
import sqlite3
import json
import threading
from datetime import datetime

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BACKEND_DIR, "orchestrator.db")

_lock = threading.RLock()


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _lock, _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS adapter_configs (
                adapter_id TEXT PRIMARY KEY,
                config_json TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS targets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                chat_endpoint TEXT,
                mcp_endpoint TEXT,
                auth_header TEXT,
                extra_json TEXT DEFAULT '{}',
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                id TEXT PRIMARY KEY,
                target_name TEXT NOT NULL,
                target_json TEXT NOT NULL,
                adapter_ids_json TEXT NOT NULL,
                status TEXT NOT NULL,
                progress_json TEXT DEFAULT '[]',
                result_json TEXT,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()


# ---------- Adapter configs ----------

def get_adapter_config(adapter_id: str) -> dict:
    with _lock, _connect() as conn:
        row = conn.execute(
            "SELECT config_json FROM adapter_configs WHERE adapter_id = ?",
            (adapter_id,)
        ).fetchone()
        return json.loads(row["config_json"]) if row else {}


def set_adapter_config(adapter_id: str, values: dict) -> dict:
    with _lock, _connect() as conn:
        row = conn.execute(
            "SELECT config_json FROM adapter_configs WHERE adapter_id = ?",
            (adapter_id,)
        ).fetchone()
        existing = json.loads(row["config_json"]) if row else {}
        existing.update(values)
        conn.execute(
            "INSERT INTO adapter_configs (adapter_id, config_json) VALUES (?, ?) "
            "ON CONFLICT(adapter_id) DO UPDATE SET config_json = excluded.config_json",
            (adapter_id, json.dumps(existing))
        )
        conn.commit()
        return existing


# ---------- Targets ----------

def list_targets() -> list:
    with _lock, _connect() as conn:
        rows = conn.execute("SELECT * FROM targets ORDER BY id DESC").fetchall()
        return [_target_row_to_dict(r) for r in rows]


def get_target(target_id: int) -> dict | None:
    with _lock, _connect() as conn:
        row = conn.execute("SELECT * FROM targets WHERE id = ?", (target_id,)).fetchone()
        return _target_row_to_dict(row) if row else None


def save_target(name, chat_endpoint=None, mcp_endpoint=None, auth_header=None, extra=None) -> dict:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO targets (name, chat_endpoint, mcp_endpoint, auth_header, extra_json, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (name, chat_endpoint, mcp_endpoint, auth_header,
             json.dumps(extra or {}), datetime.utcnow().isoformat())
        )
        conn.commit()
        return get_target(cur.lastrowid)


def delete_target(target_id: int):
    with _lock, _connect() as conn:
        conn.execute("DELETE FROM targets WHERE id = ?", (target_id,))
        conn.commit()


def _target_row_to_dict(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "chat_endpoint": row["chat_endpoint"],
        "mcp_endpoint": row["mcp_endpoint"],
        "auth_header": row["auth_header"],
        "extra": json.loads(row["extra_json"] or "{}"),
        "created_at": row["created_at"],
    }


# ---------- Scans ----------

def create_scan(scan_id, target: dict, adapter_ids: list):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO scans (id, target_name, target_json, adapter_ids_json, status, progress_json, created_at) "
            "VALUES (?, ?, ?, ?, 'running', '[]', ?)",
            (scan_id, target.get("name", "Unnamed"), json.dumps(target),
             json.dumps(adapter_ids), datetime.utcnow().isoformat())
        )
        conn.commit()


def append_progress(scan_id, message: str):
    with _lock, _connect() as conn:
        row = conn.execute("SELECT progress_json FROM scans WHERE id = ?", (scan_id,)).fetchone()
        progress = json.loads(row["progress_json"]) if row else []
        progress.append(message)
        conn.execute("UPDATE scans SET progress_json = ? WHERE id = ?", (json.dumps(progress), scan_id))
        conn.commit()


def complete_scan(scan_id, result: dict):
    with _lock, _connect() as conn:
        conn.execute(
            "UPDATE scans SET status = 'complete', result_json = ? WHERE id = ?",
            (json.dumps(result), scan_id)
        )
        conn.commit()


def get_scan(scan_id) -> dict | None:
    with _lock, _connect() as conn:
        row = conn.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
        return _scan_row_to_dict(row) if row else None


def list_scans(limit=20) -> list:
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM scans ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [_scan_row_to_dict(r) for r in rows]


def dashboard_stats() -> dict:
    with _lock, _connect() as conn:
        scan_count = conn.execute("SELECT COUNT(*) c FROM scans").fetchone()["c"]
        target_count = conn.execute("SELECT COUNT(*) c FROM targets").fetchone()["c"]

        critical_open = 0
        rows = conn.execute("SELECT result_json FROM scans WHERE status='complete'").fetchall()
        for r in rows:
            result = json.loads(r["result_json"] or "{}")
            critical_open += result.get("summary", {}).get("severity_counts", {}).get("critical", 0)

        return {
            "scans_run": scan_count,
            "saved_targets": target_count,
            "critical_open": critical_open,
        }


def _scan_row_to_dict(row):
    return {
        "id": row["id"],
        "target_name": row["target_name"],
        "target": json.loads(row["target_json"]),
        "adapter_ids": json.loads(row["adapter_ids_json"]),
        "status": row["status"],
        "progress": json.loads(row["progress_json"]),
        "result": json.loads(row["result_json"]) if row["result_json"] else None,
        "created_at": row["created_at"],
    }
