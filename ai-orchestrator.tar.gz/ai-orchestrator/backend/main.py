"""
AI Security Orchestrator - Backend

All configuration (API keys, scan scope, targets) is set through the
frontend and persisted in orchestrator.db (SQLite) - no env vars or manual
file edits required after initial install.
"""

import os
import sys
import uuid
import threading
from typing import List, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BACKEND_DIR)

import db  # noqa: E402
import registry  # noqa: E402
import catalog  # noqa: E402
from consolidate import consolidate  # noqa: E402
from report_md import generate_consolidated_report  # noqa: E402

db.init_db()

app = FastAPI(title="AI Security Orchestrator")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ============ Models ============

class TargetIn(BaseModel):
    name: str
    chat_endpoint: Optional[str] = None
    mcp_endpoint: Optional[str] = None
    auth_header: Optional[str] = None
    extra: dict = {}


class ScanRequest(BaseModel):
    target: TargetIn
    adapter_ids: List[str]
    save_target: bool = False


class ConfigIn(BaseModel):
    values: dict


# ============ Dashboard ============

@app.get("/api/dashboard")
def get_dashboard():
    adapters = registry.list_adapters()
    stats = db.dashboard_stats()
    stats["adapters_installed"] = sum(1 for a in adapters if a.get("installed"))
    stats["adapters_total"] = len(adapters)
    recent_scans = db.list_scans(limit=5)
    return {"stats": stats, "recent_scans": recent_scans}


# ============ Adapter marketplace ============

@app.get("/api/adapters")
def get_adapters():
    adapters = registry.list_adapters()
    for a in adapters:
        a.pop("_dir", None)
    return {"adapters": adapters}


@app.post("/api/adapters/{adapter_id}/install")
def install_adapter(adapter_id: str):
    def stream():
        for line in registry.install_adapter_stream(adapter_id):
            yield line
    return StreamingResponse(stream(), media_type="text/plain")


@app.get("/api/adapters/{adapter_id}/config")
def get_adapter_config(adapter_id: str):
    manifest = registry.get_adapter(adapter_id)
    if manifest is None:
        return {"error": "adapter not found"}
    saved = db.get_adapter_config(adapter_id)
    return {
        "config_schema": manifest.get("config_schema", []),
        "values": saved,
    }


@app.post("/api/adapters/{adapter_id}/config")
def set_adapter_config(adapter_id: str, body: ConfigIn):
    updated = db.set_adapter_config(adapter_id, body.values)
    return {"values": updated}


# ============ Catalog (add new adapters) ============

@app.get("/api/catalog")
def get_catalog():
    return {"catalog": catalog.list_catalog()}


@app.post("/api/catalog/{adapter_id}/add")
def add_catalog_adapter(adapter_id: str):
    try:
        result = catalog.add_from_catalog(adapter_id)
        return {"status": "added", **result}
    except ValueError as e:
        return {"status": "error", "error": str(e)}


# ============ Targets ============

@app.get("/api/targets")
def get_targets():
    return {"targets": db.list_targets()}


@app.post("/api/targets")
def create_target(target: TargetIn):
    saved = db.save_target(
        name=target.name,
        chat_endpoint=target.chat_endpoint,
        mcp_endpoint=target.mcp_endpoint,
        auth_header=target.auth_header,
        extra=target.extra,
    )
    return {"target": saved}


@app.delete("/api/targets/{target_id}")
def remove_target(target_id: int):
    db.delete_target(target_id)
    return {"status": "deleted"}


# ============ Scanning ============

@app.post("/api/scan")
def start_scan(req: ScanRequest):
    scan_id = str(uuid.uuid4())[:8]
    target_dict = req.target.dict()

    db.create_scan(scan_id, target_dict, req.adapter_ids)

    if req.save_target:
        db.save_target(
            name=target_dict["name"],
            chat_endpoint=target_dict.get("chat_endpoint"),
            mcp_endpoint=target_dict.get("mcp_endpoint"),
            auth_header=target_dict.get("auth_header"),
            extra=target_dict.get("extra", {}),
        )

    thread = threading.Thread(target=_run_scan, args=(scan_id, req))
    thread.start()

    return {"scan_id": scan_id}


def _run_scan(scan_id, req: ScanRequest):
    all_findings = []
    target_dict = req.target.dict()

    def progress_cb(msg):
        db.append_progress(scan_id, msg)

    for adapter_id in req.adapter_ids:
        manifest = registry.get_adapter(adapter_id)
        if manifest is None:
            progress_cb(f"ERROR: adapter '{adapter_id}' not found, skipping")
            continue

        if not manifest.get("installed"):
            progress_cb(f"SKIPPED: '{adapter_id}' is not installed")
            all_findings.append({
                "source_tool": adapter_id, "category": "config_error",
                "name": "Adapter not installed", "target_component": "n/a",
                "error": f"'{adapter_id}' is not installed.",
            })
            continue

        progress_cb(f"=== Starting adapter: {adapter_id} ===")
        try:
            module, fn_name = registry.load_adapter_module(adapter_id)
            run_fn = getattr(module, fn_name)
            findings = run_fn(target_dict, progress_cb=progress_cb)
            all_findings.extend(findings)
            progress_cb(f"=== Finished adapter: {adapter_id} ({len(findings)} results) ===")
        except Exception as e:
            progress_cb(f"ERROR running '{adapter_id}': {e}")
            all_findings.append({
                "source_tool": adapter_id, "category": "config_error",
                "name": "Adapter crashed", "target_component": "n/a", "error": str(e),
            })

    result = consolidate(all_findings)
    db.complete_scan(scan_id, result)


@app.get("/api/scan/{scan_id}")
def get_scan(scan_id: str):
    scan = db.get_scan(scan_id)
    if scan is None:
        return {"error": "scan not found"}
    return scan


@app.get("/api/scans")
def get_scans(limit: int = 20):
    return {"scans": db.list_scans(limit=limit)}


@app.get("/api/scan/{scan_id}/report")
def get_scan_report(scan_id: str):
    scan = db.get_scan(scan_id)
    if scan is None or scan["result"] is None:
        return {"error": "scan not found or not complete"}

    md = generate_consolidated_report(scan["result"], scan["target_name"])

    out_path = f"/tmp/report_{scan_id}.md"
    with open(out_path, "w") as f:
        f.write(md)

    return FileResponse(out_path, filename=f"report_{scan_id}.md", media_type="text/markdown")


# ============ Frontend ============

FRONTEND_DIR = os.path.join(os.path.dirname(BACKEND_DIR), "frontend")
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
