"""
Consolidation layer.

Takes raw findings (list of dicts matching schema.Finding) from multiple
adapters and produces a consolidated view:
  - Groups by category + target_component
  - Within each group, flags findings that multiple tools agree on
    ("confirmed by N tools") - these get a confidence boost
  - Leaves dedup of near-identical findings to a lightweight heuristic
    (same category + same target_component + both success=True)
"""

from collections import defaultdict

SEVERITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, None: 0}


def consolidate(all_findings: list) -> dict:
    """
    all_findings: flat list of Finding dicts from all adapters that ran.

    Returns:
    {
      "summary": {...counts...},
      "groups": [
        {
          "category": "...",
          "target_component": "...",
          "confirmed_by": ["custom_probes", "garak"],
          "max_severity": "critical",
          "findings": [ ...raw finding dicts... ]
        },
        ...
      ],
      "errors": [...],
      "raw": all_findings
    }
    """
    errors = [f for f in all_findings if f.get("error")]
    confirmed = [f for f in all_findings if f.get("success") is True]
    safe = [f for f in all_findings if f.get("success") is False]

    groups_map = defaultdict(list)
    for f in confirmed:
        key = (f["category"], f["target_component"])
        groups_map[key].append(f)

    groups = []
    for (category, component), findings in groups_map.items():
        tools = sorted(set(f["source_tool"] for f in findings))
        max_sev = max(
            (f.get("severity") for f in findings),
            key=lambda s: SEVERITY_RANK.get(s, 0)
        )
        groups.append({
            "category": category,
            "target_component": component,
            "confirmed_by": tools,
            "cross_validated": len(tools) > 1,
            "max_severity": max_sev,
            "finding_count": len(findings),
            "findings": findings,
        })

    # Sort: cross-validated + highest severity first
    groups.sort(
        key=lambda g: (g["cross_validated"], SEVERITY_RANK.get(g["max_severity"], 0)),
        reverse=True,
    )

    by_tool = defaultdict(lambda: {"confirmed": 0, "safe": 0, "errors": 0})
    for f in all_findings:
        tool = f["source_tool"]
        if f.get("error"):
            by_tool[tool]["errors"] += 1
        elif f.get("success") is True:
            by_tool[tool]["confirmed"] += 1
        elif f.get("success") is False:
            by_tool[tool]["safe"] += 1

    summary = {
        "total_probes_run": len(all_findings),
        "confirmed_findings": len(confirmed),
        "safe_results": len(safe),
        "errors": len(errors),
        "groups": len(groups),
        "cross_validated_groups": sum(1 for g in groups if g["cross_validated"]),
        "by_tool": dict(by_tool),
        "severity_counts": {
            sev: sum(1 for f in confirmed if f.get("severity") == sev)
            for sev in ["critical", "high", "medium", "low"]
        },
    }

    return {
        "summary": summary,
        "groups": groups,
        "errors": errors,
        "raw": all_findings,
    }
