"""
Common schema that EVERY adapter must return findings in.

Each adapter's run_scan(target_config) -> List[Finding]

This is the contract that makes "plug and play" possible: the orchestrator
and frontend only ever deal with this shape, regardless of which underlying
tool (garak, mcp-scan, custom probes, etc.) produced it.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Finding:
    source_tool: str            # e.g. "custom_probes", "garak", "mcp-scan"
    category: str               # e.g. "jailbreak", "system_prompt_extraction"
    name: str                   # human-readable probe/check name
    target_component: str       # e.g. "chat_endpoint", "mcp_server:tool_x"
    payload: Optional[str] = None
    response_excerpt: Optional[str] = None
    success: Optional[bool] = None     # True = vulnerability confirmed
    severity: Optional[str] = None     # critical/high/medium/low
    confidence: Optional[str] = None   # high/medium/low
    evidence: Optional[str] = None
    explanation: Optional[str] = None
    remediation: Optional[str] = None
    raw_ref: Optional[str] = None      # path/id to raw tool output, if useful
    error: Optional[str] = None
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


@dataclass
class TargetConfig:
    """Describes the target being scanned. Adapters read what they need."""
    name: str
    chat_endpoint: Optional[str] = None      # e.g. http://host/chat
    mcp_endpoint: Optional[str] = None        # e.g. http://host/mcp
    auth_header: Optional[str] = None         # e.g. "Bearer xyz"
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)
