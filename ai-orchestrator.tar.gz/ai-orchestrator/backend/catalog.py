"""
Catalog of known adapters that aren't yet copied into adapters/ but can be
added with one click from the "Add Adapter" screen.

Each entry contains the manifest.yaml content AND the adapter.py content as
strings - "adding" an adapter writes both files into adapters/<id>/, after
which it behaves exactly like any other adapter (shows in marketplace,
installable, configurable, runnable).
"""

import os
import yaml

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BACKEND_DIR)
ADAPTERS_DIR = os.path.join(ROOT_DIR, "adapters")


MCP_SCAN_MANIFEST = """
id: mcp_scan
name: "MCP-Scan (Invariant Labs)"
description: "Scans MCP servers for tool poisoning, prompt injection in tool descriptions, and auth misconfigurations."
category: mcp_security
version: "0.1"
homepage: "https://github.com/invariantlabs-ai/mcp-scan"

install:
  type: pip
  package: mcp-scan

run:
  entrypoint: adapter.py
  function: run_scan

input_requires:
  - mcp_endpoint

output_categories:
  - mcp_tool_poisoning
  - mcp_auth
"""

MCP_SCAN_ADAPTER = '''
"""
Adapter: mcp_scan

Wraps invariantlabs-ai/mcp-scan via its CLI to scan an MCP server endpoint
for tool poisoning, prompt-injection-in-tool-descriptions, and auth issues.
"""

import os
import sys
import shutil
import subprocess
import json

ADAPTER_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ADAPTER_DIR, "..", "..", "backend"))
from schema import Finding  # noqa: E402


def is_installed():
    return shutil.which("mcp-scan") is not None


def run_scan(target_config: dict, progress_cb=None) -> list:
    mcp_endpoint = target_config.get("mcp_endpoint")

    if not mcp_endpoint:
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="Missing mcp_endpoint",
            target_component="n/a",
            error="mcp_scan adapter requires \\'mcp_endpoint\\' in target config",
        ).to_dict()]

    if not is_installed():
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="mcp-scan not installed",
            target_component="n/a",
            error="Install mcp-scan from the Adapter Marketplace first.",
        ).to_dict()]

    if progress_cb:
        progress_cb(f"[mcp_scan] Scanning {mcp_endpoint}")

    try:
        result = subprocess.run(
            ["mcp-scan", "scan", mcp_endpoint, "--json"],
            capture_output=True, text=True, timeout=300
        )
    except subprocess.TimeoutExpired:
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="mcp-scan timed out",
            target_component="mcp_endpoint",
            error="Scan exceeded 5 minute timeout",
        ).to_dict()]

    findings = []
    try:
        data = json.loads(result.stdout)
        issues = data.get("issues", [])
        for issue in issues:
            findings.append(Finding(
                source_tool="mcp_scan",
                category="mcp_tool_poisoning",
                name=issue.get("name", "MCP issue"),
                target_component=f"mcp_server:{issue.get('tool', 'unknown')}",
                success=True,
                severity=issue.get("severity", "medium"),
                confidence="high",
                evidence=issue.get("description", ""),
                explanation=issue.get("description", ""),
            ).to_dict())

        if not issues:
            findings.append(Finding(
                source_tool="mcp_scan",
                category="mcp_tool_poisoning",
                name="MCP server scan",
                target_component="mcp_endpoint",
                success=False,
                confidence="high",
                explanation="mcp-scan found no issues with this MCP server.",
            ).to_dict())

    except json.JSONDecodeError:
        findings.append(Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="Could not parse mcp-scan output",
            target_component="mcp_endpoint",
            error=(result.stdout + result.stderr)[-1000:],
        ).to_dict())

    return findings
'''


MODELSCAN_MANIFEST = """
id: modelscan
name: "ModelScan (Protect AI)"
description: "Scans serialized model files (pickle, etc.) for embedded malicious code before they're loaded."
category: model_artifact_scanning
version: "0.1"
homepage: "https://github.com/protectai/modelscan"

config_schema:
  - key: model_path
    label: "Path to model file"
    type: text
    required: true
    placeholder: "/path/to/model.pkl"

install:
  type: pip
  package: modelscan

run:
  entrypoint: adapter.py
  function: run_scan

input_requires: []

output_categories:
  - malicious_model_file
"""

MODELSCAN_ADAPTER = '''
"""
Adapter: modelscan

Wraps protectai/modelscan to check a local model file for unsafe/malicious
serialized code (e.g. pickle exploits).
"""

import os
import sys
import shutil
import subprocess
import json

ADAPTER_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ADAPTER_DIR, "..", "..", "backend"))
from schema import Finding  # noqa: E402
import registry  # noqa: E402


def is_installed():
    return shutil.which("modelscan") is not None


def run_scan(target_config: dict, progress_cb=None) -> list:
    manifest = registry.get_adapter("modelscan")
    model_path = registry.get_config_value("modelscan", manifest, "model_path")

    if not model_path:
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="Missing model_path",
            target_component="n/a",
            error="Set \\'model_path\\' in the modelscan adapter\\'s Configure panel.",
        ).to_dict()]

    if not os.path.exists(model_path):
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="Model file not found",
            target_component=model_path,
            error=f"No file found at {model_path}",
        ).to_dict()]

    if not is_installed():
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="modelscan not installed",
            target_component="n/a",
            error="Install modelscan from the Adapter Marketplace first.",
        ).to_dict()]

    if progress_cb:
        progress_cb(f"[modelscan] Scanning {model_path}")

    try:
        result = subprocess.run(
            ["modelscan", "-p", model_path, "-r", "json"],
            capture_output=True, text=True, timeout=300
        )
    except subprocess.TimeoutExpired:
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="modelscan timed out",
            target_component=model_path,
            error="Scan exceeded 5 minute timeout",
        ).to_dict()]

    findings = []
    try:
        data = json.loads(result.stdout)
        issues = data.get("issues", [])
        for issue in issues:
            findings.append(Finding(
                source_tool="modelscan",
                category="malicious_model_file",
                name=issue.get("description", "Model scan issue"),
                target_component=model_path,
                success=True,
                severity=issue.get("severity", "high").lower(),
                confidence="high",
                evidence=str(issue),
                explanation=issue.get("description", ""),
            ).to_dict())

        if not issues:
            findings.append(Finding(
                source_tool="modelscan",
                category="malicious_model_file",
                name="Model file scan",
                target_component=model_path,
                success=False,
                confidence="high",
                explanation="No unsafe operators/code found in this model file.",
            ).to_dict())

    except json.JSONDecodeError:
        findings.append(Finding(
            source_tool="modelscan",
            category="config_error",
            name="Could not parse modelscan output",
            target_component=model_path,
            error=(result.stdout + result.stderr)[-1000:],
        ).to_dict())

    return findings
'''


CATALOG = {
    "mcp_scan": {
        "manifest": MCP_SCAN_MANIFEST,
        "adapter": MCP_SCAN_ADAPTER,
        "preview": yaml.safe_load(MCP_SCAN_MANIFEST),
    },
    "modelscan": {
        "manifest": MODELSCAN_MANIFEST,
        "adapter": MODELSCAN_ADAPTER,
        "preview": yaml.safe_load(MODELSCAN_MANIFEST),
    },
}


def list_catalog():
    """Return catalog entries not yet added to adapters/."""
    result = []
    for adapter_id, entry in CATALOG.items():
        already_added = os.path.isdir(os.path.join(ADAPTERS_DIR, adapter_id))
        result.append({
            "id": adapter_id,
            "name": entry["preview"]["name"],
            "description": entry["preview"]["description"],
            "category": entry["preview"]["category"],
            "homepage": entry["preview"].get("homepage"),
            "already_added": already_added,
        })
    return result


def add_from_catalog(adapter_id):
    if adapter_id not in CATALOG:
        raise ValueError(f"'{adapter_id}' is not in the catalog")

    entry = CATALOG[adapter_id]
    adapter_dir = os.path.join(ADAPTERS_DIR, adapter_id)
    os.makedirs(adapter_dir, exist_ok=True)

    with open(os.path.join(adapter_dir, "manifest.yaml"), "w") as f:
        f.write(entry["manifest"].strip() + "\n")

    with open(os.path.join(adapter_dir, "adapter.py"), "w") as f:
        f.write(entry["adapter"].strip() + "\n")

    return {"id": adapter_id, "path": adapter_dir}
