"""
Adapter registry: discovers adapters under adapters/, reads manifests,
checks install status, runs installs, and exposes per-adapter configuration
(backed by db.py - persisted, editable entirely from the frontend).
"""

import os
import sys
import subprocess
import importlib.util
import yaml

import db

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BACKEND_DIR)
ADAPTERS_DIR = os.path.join(ROOT_DIR, "adapters")


def list_adapters():
    """Return list of adapter manifests with install + config status."""
    adapters = []
    for entry in sorted(os.listdir(ADAPTERS_DIR)):
        adapter_dir = os.path.join(ADAPTERS_DIR, entry)
        manifest_path = os.path.join(adapter_dir, "manifest.yaml")
        if not os.path.isfile(manifest_path):
            continue

        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)

        manifest["installed"] = check_installed(manifest)
        manifest["configured"] = is_configured(manifest)
        manifest["_dir"] = adapter_dir
        adapters.append(manifest)

    return adapters


def get_adapter(adapter_id):
    for a in list_adapters():
        if a["id"] == adapter_id:
            return a
    return None


def check_installed(manifest):
    install = manifest.get("install", {})
    itype = install.get("type", "none")

    if itype == "none":
        return True
    if itype == "pip":
        return _pip_package_installed(install["package"])
    if itype == "binary":
        return _which(install["binary"]) is not None
    return False


def _pip_package_installed(pkg_name):
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", pkg_name],
            capture_output=True, text=True, timeout=30
        )
        return result.returncode == 0
    except Exception:
        return False


def _which(binary):
    import shutil
    return shutil.which(binary)


# ---------- Config (persisted via db.py) ----------

def is_configured(manifest) -> bool:
    """True if all REQUIRED config_schema fields have a saved value or env fallback."""
    schema = manifest.get("config_schema", [])
    if not schema:
        return True

    saved = db.get_adapter_config(manifest["id"])

    for field in schema:
        if not field.get("required", False):
            continue
        key = field["key"]
        if saved.get(key):
            continue
        env_fallback = field.get("env_fallback")
        if env_fallback and os.environ.get(env_fallback):
            continue
        return False

    return True


def get_config_value(adapter_id, manifest, key):
    saved = db.get_adapter_config(adapter_id)
    if saved.get(key):
        return saved[key]
    for field in manifest.get("config_schema", []):
        if field["key"] == key and field.get("env_fallback"):
            return os.environ.get(field["env_fallback"])
    return None


def get_all_config(adapter_id, manifest) -> dict:
    """Return effective config (saved values + env fallbacks) for an adapter."""
    result = {}
    for field in manifest.get("config_schema", []):
        result[field["key"]] = get_config_value(adapter_id, manifest, field["key"])
    return result


# ---------- Install ----------

def install_adapter_stream(adapter_id):
    manifest = get_adapter(adapter_id)
    if manifest is None:
        yield f"ERROR: adapter '{adapter_id}' not found\n"
        return

    install = manifest.get("install", {})
    itype = install.get("type", "none")

    if itype == "none":
        yield f"'{adapter_id}' requires no installation.\n"
        return

    if itype == "pip":
        cmd = [sys.executable, "-m", "pip", "install", install["package"], "--break-system-packages"]
    elif itype == "git":
        target = os.path.join(ADAPTERS_DIR, adapter_id, "_src")
        cmd = ["git", "clone", "--depth", "1", install["repo"], target]
    else:
        yield f"ERROR: unsupported install type '{itype}'\n"
        return

    yield f"$ {' '.join(cmd)}\n"

    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in process.stdout:
        yield line
    process.wait()

    if process.returncode == 0:
        yield f"\n[ok] '{adapter_id}' installed successfully.\n"
    else:
        yield f"\n[!!] install failed with exit code {process.returncode}\n"


# ---------- Run ----------

def load_adapter_module(adapter_id):
    manifest = get_adapter(adapter_id)
    if manifest is None:
        raise ValueError(f"Adapter '{adapter_id}' not found")

    run_config = manifest.get("run", {})
    entrypoint = run_config.get("entrypoint", "adapter.py")
    module_path = os.path.join(manifest["_dir"], entrypoint)

    spec = importlib.util.spec_from_file_location(f"adapter_{adapter_id}", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, run_config.get("function", "run_scan")
