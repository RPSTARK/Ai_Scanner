"""
Adapter: mcp_scan

Wraps invariantlabs-ai/mcp-scan via its CLI to scan an MCP server endpoint
for tool poisoning, prompt-injection-in-tool-descriptions, and auth issues.
"""

import os
import sys
import shutil
import subprocess
import json

ADAPTER_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ADAPTER_DIR, "..", "..", "backend"))
from schema import Finding  # noqa: E402


def is_installed():
    return shutil.which("mcp-scan") is not None


def run_scan(target_config: dict, progress_cb=None) -> list:
    mcp_endpoint = target_config.get("mcp_endpoint")

    if not mcp_endpoint:
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="Missing mcp_endpoint",
            target_component="n/a",
            error="mcp_scan adapter requires \'mcp_endpoint\' in target config",
        ).to_dict()]

    if not is_installed():
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="mcp-scan not installed",
            target_component="n/a",
            error="Install mcp-scan from the Adapter Marketplace first.",
        ).to_dict()]

    if progress_cb:
        progress_cb(f"[mcp_scan] Scanning {mcp_endpoint}")

    try:
        result = subprocess.run(
            ["mcp-scan", "scan", mcp_endpoint, "--json"],
            capture_output=True, text=True, timeout=300
        )
    except subprocess.TimeoutExpired:
        return [Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="mcp-scan timed out",
            target_component="mcp_endpoint",
            error="Scan exceeded 5 minute timeout",
        ).to_dict()]

    findings = []
    try:
        data = json.loads(result.stdout)
        issues = data.get("issues", [])
        for issue in issues:
            findings.append(Finding(
                source_tool="mcp_scan",
                category="mcp_tool_poisoning",
                name=issue.get("name", "MCP issue"),
                target_component=f"mcp_server:{issue.get('tool', 'unknown')}",
                success=True,
                severity=issue.get("severity", "medium"),
                confidence="high",
                evidence=issue.get("description", ""),
                explanation=issue.get("description", ""),
            ).to_dict())

        if not issues:
            findings.append(Finding(
                source_tool="mcp_scan",
                category="mcp_tool_poisoning",
                name="MCP server scan",
                target_component="mcp_endpoint",
                success=False,
                confidence="high",
                explanation="mcp-scan found no issues with this MCP server.",
            ).to_dict())

    except json.JSONDecodeError:
        findings.append(Finding(
            source_tool="mcp_scan",
            category="config_error",
            name="Could not parse mcp-scan output",
            target_component="mcp_endpoint",
            error=(result.stdout + result.stderr)[-1000:],
        ).to_dict())

    return findings
