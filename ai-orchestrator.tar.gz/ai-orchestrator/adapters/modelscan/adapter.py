"""
Adapter: modelscan

Wraps protectai/modelscan to check a local model file for unsafe/malicious
serialized code (e.g. pickle exploits).
"""

import os
import sys
import shutil
import subprocess
import json

ADAPTER_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ADAPTER_DIR, "..", "..", "backend"))
from schema import Finding  # noqa: E402
import registry  # noqa: E402


def is_installed():
    return shutil.which("modelscan") is not None


def run_scan(target_config: dict, progress_cb=None) -> list:
    manifest = registry.get_adapter("modelscan")
    model_path = registry.get_config_value("modelscan", manifest, "model_path")

    if not model_path:
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="Missing model_path",
            target_component="n/a",
            error="Set \'model_path\' in the modelscan adapter\'s Configure panel.",
        ).to_dict()]

    if not os.path.exists(model_path):
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="Model file not found",
            target_component=model_path,
            error=f"No file found at {model_path}",
        ).to_dict()]

    if not is_installed():
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="modelscan not installed",
            target_component="n/a",
            error="Install modelscan from the Adapter Marketplace first.",
        ).to_dict()]

    if progress_cb:
        progress_cb(f"[modelscan] Scanning {model_path}")

    try:
        result = subprocess.run(
            ["modelscan", "-p", model_path, "-r", "json"],
            capture_output=True, text=True, timeout=300
        )
    except subprocess.TimeoutExpired:
        return [Finding(
            source_tool="modelscan",
            category="config_error",
            name="modelscan timed out",
            target_component=model_path,
            error="Scan exceeded 5 minute timeout",
        ).to_dict()]

    findings = []
    try:
        data = json.loads(result.stdout)
        issues = data.get("issues", [])
        for issue in issues:
            findings.append(Finding(
                source_tool="modelscan",
                category="malicious_model_file",
                name=issue.get("description", "Model scan issue"),
                target_component=model_path,
                success=True,
                severity=issue.get("severity", "high").lower(),
                confidence="high",
                evidence=str(issue),
                explanation=issue.get("description", ""),
            ).to_dict())

        if not issues:
            findings.append(Finding(
                source_tool="modelscan",
                category="malicious_model_file",
                name="Model file scan",
                target_component=model_path,
                success=False,
                confidence="high",
                explanation="No unsafe operators/code found in this model file.",
            ).to_dict())

    except json.JSONDecodeError:
        findings.append(Finding(
            source_tool="modelscan",
            category="config_error",
            name="Could not parse modelscan output",
            target_component=model_path,
            error=(result.stdout + result.stderr)[-1000:],
        ).to_dict())

    return findings
