"""
Adapter: garak

Wraps NVIDIA's garak (https://github.com/NVIDIA/garak) - a mature, widely-used
LLM vulnerability scanner with 100+ probe modules.

How it works:
  1. Writes a temporary garak REST generator config pointing at the target's
     chat_endpoint (garak's "rest" generator type can call arbitrary HTTP APIs).
  2. Runs `python -m garak` via subprocess with a curated subset of probes
     (running garak's FULL probe set can take hours - we scope it down for
     a reasonable scan time; this list can be expanded later).
  3. Parses garak's JSONL report output and maps each result to our common
     Finding schema.

NOTE: garak's REST config format may vary slightly between versions. This
adapter targets garak >= 0.10. If the config format has changed, the
subprocess will fail with a clear error captured in the Finding's `error`
field - check `raw garak output` referenced in raw_ref for debugging.
"""

import os
import sys
import json
import shutil
import subprocess
import tempfile

ADAPTER_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ADAPTER_DIR, "..", "..", "backend"))
from schema import Finding  # noqa: E402
import registry  # noqa: E402


# A curated subset of garak probes - fast-ish, high-signal categories.
# Full list: https://reference.garak.ai/en/latest/probes.html
DEFAULT_PROBES = [
    "promptinject",      # prompt injection attacks
    "dan",               # DAN-style jailbreaks
    "leakreplay",        # training data / system prompt leakage
    "encoding",          # encoding-based jailbreaks
]

CATEGORY_MAP = {
    "promptinject": "prompt_injection",
    "dan": "jailbreak",
    "leakreplay": "data_leakage",
    "encoding": "jailbreak",
}


def is_installed():
    return shutil.which("garak") is not None or _module_installed("garak")


def _module_installed(module_name):
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


def build_rest_config(chat_endpoint, auth_header, config_path):
    """
    Build a garak REST generator config.

    garak's rest generator sends a JSON request and extracts the reply via
    a JSONPath-like field. Our target API contract is:
        POST {"message": "<prompt>", "history": []}
        -> {"reply": "<response>"}
    """
    headers = {"Content-Type": "application/json"}
    if auth_header:
        headers["Authorization"] = auth_header

    config = {
        "rest": {
            "RestGenerator": {
                "uri": chat_endpoint,
                "method": "post",
                "headers": headers,
                "req_template_json": {
                    "message": "$INPUT",
                    "history": []
                },
                "response_json": True,
                "response_json_field": "reply"
            }
        }
    }

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def run_scan(target_config: dict, progress_cb=None) -> list:
    chat_endpoint = target_config.get("chat_endpoint")
    auth_header = target_config.get("auth_header")

    manifest = registry.get_adapter("garak")
    cfg = registry.get_all_config("garak", manifest)
    probes = cfg.get("probe_modules") or DEFAULT_PROBES

    if not chat_endpoint:
        return [Finding(
            source_tool="garak",
            category="config_error",
            name="Missing chat_endpoint",
            target_component="n/a",
            error="garak adapter requires 'chat_endpoint' in target config",
        ).to_dict()]

    if not is_installed():
        return [Finding(
            source_tool="garak",
            category="config_error",
            name="garak not installed",
            target_component="n/a",
            error="garak is not installed. Install it from the Adapter Marketplace first.",
        ).to_dict()]

    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = os.path.join(tmpdir, "garak_rest_config.json")
        report_prefix = os.path.join(tmpdir, "garak_run")

        build_rest_config(chat_endpoint, auth_header, config_path)

        cmd = [
            sys.executable, "-m", "garak",
            "--model_type", "rest",
            "--generator_option_file", config_path,
            "--probes", ",".join(probes),
            "--report_prefix", report_prefix,
        ]

        if progress_cb:
            progress_cb(f"[garak] Running: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=1800
            )
        except subprocess.TimeoutExpired:
            return [Finding(
                source_tool="garak",
                category="config_error",
                name="garak scan timed out",
                target_component="chat_endpoint",
                error="garak scan exceeded 30 minute timeout",
            ).to_dict()]

        report_path = report_prefix + ".report.jsonl"

        if not os.path.exists(report_path):
            return [Finding(
                source_tool="garak",
                category="config_error",
                name="garak produced no report",
                target_component="chat_endpoint",
                error=(result.stderr or result.stdout)[-2000:],
            ).to_dict()]

        return _parse_report(report_path, progress_cb)


def _parse_report(report_path, progress_cb=None) -> list:
    """
    Parse garak's .report.jsonl. Each line is a JSON object; entries with
    entry_type == "eval" contain pass/fail info per probe/detector.
    """
    findings = []

    with open(report_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            if entry.get("entry_type") != "eval":
                continue

            probe_name = entry.get("probe", "unknown")
            probe_short = probe_name.split(".")[0] if "." in probe_name else probe_name
            category = CATEGORY_MAP.get(probe_short, "misc")

            passed = entry.get("passed", 0)
            total = entry.get("total", 0)
            failed = total - passed if total else 0

            if failed > 0:
                findings.append(Finding(
                    source_tool="garak",
                    category=category,
                    name=f"garak probe: {probe_name} / {entry.get('detector', '')}",
                    target_component="chat_endpoint",
                    success=True,
                    severity="high" if category in ("jailbreak", "data_leakage") else "medium",
                    confidence="high",
                    evidence=f"{failed}/{total} test cases failed (vulnerability triggered)",
                    explanation=(
                        f"garak's '{probe_name}' probe found that the target failed "
                        f"{failed} out of {total} adversarial test cases for the "
                        f"'{entry.get('detector', '')}' detector."
                    ),
                    raw_ref=report_path,
                ).to_dict())
            else:
                findings.append(Finding(
                    source_tool="garak",
                    category=category,
                    name=f"garak probe: {probe_name} / {entry.get('detector', '')}",
                    target_component="chat_endpoint",
                    success=False,
                    confidence="high",
                    evidence=f"{passed}/{total} test cases passed",
                    explanation=f"No issues found by garak's '{probe_name}' probe.",
                    raw_ref=report_path,
                ).to_dict())

    if progress_cb:
        progress_cb(f"[garak] Parsed {len(findings)} result entries from report")

    return findings
